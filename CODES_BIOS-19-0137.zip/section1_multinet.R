

library(pacman)
p_load(tidyverse,tidytext,gridExtra,multinets)
p_load(ggraph,igraph,tidygraph,widyr)

load("BIOSCIENCE_RESUBMIT\\DATA\\lter.rds")
load("BIOSCIENCE_RESUBMIT\\DATA\\baseline.rds")


######################################figure 2

read_csv("BIOSCIENCE_RESUBMIT\\DATA\\LTER-network-library-2019004-25.csv") -> lter_raw

# visualization of institutions and sites

lter_raw %>% 
  transmute(year = `Publication Year`,
            Title,
            site = `Manual Tags`) %>% 
  filter(between(year,1981,2018)) %>% 
  distinct(Title,.keep_all = T) %>% 
  unnest_tokens(site,site,str_split,pattern = "; ") %>% 
  filter(str_detect(site,"^lter-")) %>% 
  mutate(site = str_to_upper(site)) %>% 
  group_by(year,Title) %>% 
  summarise(site = str_c(site,collapse = "; ")) %>% 
  ungroup()-> site_info

lter_aff %>% 
  group_by(search_txt,entry_number) %>% 
  summarise(afid = str_c(afid,collapse = "; ")) -> afid_info

lter_df %>% 
  select(eid,year,Title,search_txt,entry_number) %>% 
  inner_join(site_info) %>% 
  inner_join(afid_info) %>% 
  select(year,eid,site,afid) -> site_afid

vis_site_afid_net = function(yr){
  
  site_afid %>% 
    filter(year == yr) %>% 
    unnest_tokens(site,site,token = str_split,pattern = "; ") %>% 
    mutate(site = str_to_upper(site)) %>% 
    count(site) -> site_no
  
  site_afid %>% 
    filter(year == yr) %>% 
    unite(site,afid,col = mix,sep = "; ") %>% 
    unnest_tokens(mix,mix,token = str_split,pattern = "; ") %>% 
    mutate(mix = str_to_upper(mix)) %>% 
    pairwise_count(mix,eid,upper = F) %>% 
    graph_from_data_frame(directed = F) %>% 
    as_tbl_graph() %>% 
    mutate(is_site = str_detect(name,"^LTER-")) %>%
    left_join(site_no,by = c("name"="site")) %>% 
    mutate(n = replace_na(n,1)) %>% 
    rename(node_size = n) %>% 
    mutate(node_label = ifelse(str_detect(name,"^LTER-"),
                               str_sub(name,-3,-1),"")) %>% 
    mutate(id = 1:n())-> g
  
  g %>% 
    activate(nodes) %>% 
    select(-name,-node_size) %>% 
    as_tibble() -> node_list
  
  g %>% 
    activate(edges) %>% 
    inner_join(node_list,by = c("from"="id")) %>% 
    rename(from_is_site = is_site) %>% 
    inner_join(node_list,by = c("to"="id")) %>% 
    rename(to_is_site = is_site) %>% 
    mutate(link = case_when(
      from_is_site + to_is_site == 0 ~ "AFF_AFF",
      from_is_site + to_is_site == 1 ~ "SITE_AFF",
      from_is_site + to_is_site == 2 ~ "SITE_SITE"
    )) %>% 
    select(-from_is_site,-to_is_site) %>% 
    activate(nodes) %>% 
    mutate(type = ifelse(node_label == "",F,T)) %>% 
    add_layout_(as_bipartite()) -> multi_net
  
  l <- layout_multilevel(multi_net, layout = layout_with_kk)
  
  # Set different colors and shapes for each level vertices
  multi_net <- set_color_multilevel(multi_net)
  multi_net <- set_shape_multilevel(multi_net)
  
  # Plot
  multi_net %>% plot(main = yr,layout = l, vertex.size = 2, vertex.label = V(.) %>% .$node_label,
                     vertex.label.dist = 1,family = NULL)
  
}





# par(mfrow=c(2,2))

# postscript("Figure3.eps",width = 10,height = 8,fonts=c("serif", "Palatino"))
# par(mar=c(1,1,1,1))

vis_site_afid_net(1985) 
vis_site_afid_net(1995) 
vis_site_afid_net(2005) 
vis_site_afid_net(2015) 
# dev.off()


# 2000 %>% get_site_afid_net() %>% vis_site_afid_net()




