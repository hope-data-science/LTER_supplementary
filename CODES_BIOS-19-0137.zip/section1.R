

library(pacman)
p_load(tidyverse,tidytext,gridExtra)
p_load(ggraph,igraph,tidygraph,widyr)

load("BIOSCIENCE_RESUBMIT\\DATA\\lter.rds")
load("BIOSCIENCE_RESUBMIT\\DATA\\baseline.rds")

#################figure 1
lter_df %>% 
  group_by(year) %>% 
  summarise(avg.no = mean(author_no)) %>% 
  mutate(class = "LTER") -> lter.author

eco_df %>% 
  #filter(between(year,1981,2018)) %>% 
  group_by(year) %>% 
  summarise(avg.no = mean(author_no,na.rm = T)) %>% 
  na.omit() %>% 
  mutate(class = "Baseline") -> eco.author

bind_rows(lter.author,eco.author) %>%
  ggplot(aes(year,avg.no,group = class)) +
  geom_point(aes(shape=class,colour=class),size=2)+
  geom_smooth(aes(colour=class,linetype = class),se = F) +
  scale_linetype_manual(breaks=c("Baseline","LTER"), 
                        values=c(2,1))+
  scale_color_manual(breaks=c("Baseline","LTER"), 
                     values=c("#0000CD","#FF2400")) +
  theme_bw() +
  ylab("Average author no. per article\n") + xlab("\nYear") +
  theme(legend.position=c(0,1), legend.justification=c(0,1))+
  theme(legend.background=element_rect(fill="white", colour="black")) +
  theme(legend.title=element_blank()) +
  ggtitle("(a)") -> plotA

# plotA

lter_df %>% 
  inner_join(lter_aff) %>% 
  group_by(year,eid) %>% 
  summarise(n = n()) %>% 
  ungroup() %>% 
  group_by(year) %>% 
  summarise(avg.no = mean(n)) %>% 
  mutate(class = "LTER") -> lter.affl

eco_df %>% 
  #filter(between(year,1981,2018)) %>% 
  inner_join(eco_aff) %>% 
  group_by(year,eid) %>% 
  summarise(n = n()) %>% 
  ungroup() %>% 
  group_by(year) %>% 
  summarise(avg.no = mean(n)) %>% 
  mutate(class = "Baseline") -> eco.affl

bind_rows(lter.affl,eco.affl) %>%
  ggplot(aes(year,avg.no,group = class)) +
  geom_point(aes(shape=class,colour=class),size=2)+
  geom_smooth(aes(colour=class,linetype = class),se = F) +
  scale_linetype_manual(breaks=c("Baseline","LTER"), 
                        values=c(2,1))+
  scale_color_manual(breaks=c("Baseline","LTER"), 
                     values=c("#0000CD","#FF2400")) +
  theme_bw() +
  ylab("Average institution no. per article\n") + xlab("\NYear") +
  theme(legend.position=c(0,1), legend.justification=c(0,1))+
  theme(legend.background=element_rect(fill="white", colour="black")) +
  theme(legend.title=element_blank())+
  ggtitle("(b)") -> plotB

# plotB

grid.arrange(plotA,plotB,nrow = 2) -> plotAB

p=1
ggsave("Fig_2.eps",plotAB,dpi = 400,width = 4*p,height = 6*p)

######################################figure 2

read_csv("BIOSCIENCE_RESUBMIT\\DATA\\LTER-network-library-2019004-25.csv") -> lter_raw

# visualization of institutions and sites

lter_raw %>% 
  transmute(year = `Publication Year`,
            Title,
            site = `Manual Tags`) %>% 
  filter(between(year,1981,2018)) %>% 
  distinct(Title,.keep_all = T) %>% 
  unnest_tokens(site,site,str_split,pattern = "; ") %>% 
  filter(str_detect(site,"^lter-")) %>% 
  mutate(site = str_to_upper(site)) %>% 
  group_by(year,Title) %>% 
  summarise(site = str_c(site,collapse = "; ")) %>% 
  ungroup()-> site_info

lter_aff %>% 
  group_by(search_txt,entry_number) %>% 
  summarise(afid = str_c(afid,collapse = "; ")) -> afid_info

lter_df %>% 
  select(eid,year,Title,search_txt,entry_number) %>% 
  inner_join(site_info) %>% 
  inner_join(afid_info) %>% 
  select(year,eid,site,afid) -> site_afid

vis_site_afid_net = function(yr){
  
  site_afid %>% 
    filter(year == yr) %>% 
    unnest_tokens(site,site,token = str_split,pattern = "; ") %>% 
    mutate(site = str_to_upper(site)) %>% 
    count(site) -> site_no
  
  site_afid %>% 
    filter(year == yr) %>% 
    unite(site,afid,col = mix,sep = "; ") %>% 
    unnest_tokens(mix,mix,token = str_split,pattern = "; ") %>% 
    mutate(mix = str_to_upper(mix)) %>% 
    pairwise_count(mix,eid,upper = F) %>% 
    graph_from_data_frame(directed = F) %>% 
    as_tbl_graph() %>% 
    mutate(is_site = str_detect(name,"^LTER-")) %>%
    left_join(site_no,by = c("name"="site")) %>% 
    mutate(n = replace_na(n,1)) %>% 
    rename(node_size = n) %>% 
    mutate(node_label = ifelse(str_detect(name,"^LTER-"),
                               str_sub(name,-3,-1),"")) %>% 
    mutate(id = 1:n())-> g
  
  g %>% 
    activate(nodes) %>% 
    select(-name,-node_size) %>% 
    as_tibble() -> node_list
  
  g %>% 
    activate(edges) %>% 
    inner_join(node_list,by = c("from"="id")) %>% 
    rename(from_is_site = is_site) %>% 
    inner_join(node_list,by = c("to"="id")) %>% 
    rename(to_is_site = is_site) %>% 
    mutate(link = case_when(
      from_is_site + to_is_site == 0 ~ "AFF_AFF",
      from_is_site + to_is_site == 1 ~ "SITE_AFF",
      from_is_site + to_is_site == 2 ~ "SITE_SITE"
    )) %>% 
    select(-from_is_site,-to_is_site) %>% 
    ggraph(layout = "kk") +
    geom_edge_link(aes(alpha=.3)) + 
    #geom_node_point(aes(colour = is_site,shape = is_site,size = node_size)) +
    geom_node_point(aes(colour = is_site,shape = is_site)) +
    geom_node_text(aes(label = node_label),colour = "red",repel = T) +
    scale_colour_manual(values = c("TRUE"= "red","FALSE" = "black")) +
    theme_graph(fg_text_colour = 'white') +
    theme(legend.position = "none") +
    ggtitle(yr)
}



# 2000 %>% get_site_afid_net() %>% vis_site_afid_net()

1985 %>% vis_site_afid_net() -> g1
1995 %>% vis_site_afid_net() -> g2
2005 %>% vis_site_afid_net() -> g3
2015 %>% vis_site_afid_net() -> g4

system.time(grid.arrange(g1,g2,g3,g4,nrow = 2))

######################################figure 3

# rely on figure 2 data site_afid

p_load(bc3net)

get_metrics = function(yr){
  
  site_afid %>% 
    select(-site) %>% 
    filter(year == yr) %>% 
    unnest_tokens(afid,afid,token = str_split,pattern = "; ") %>% 
    pairwise_count(afid,eid,upper = F) %>% 
    graph_from_data_frame(directed = F) %>% 
    as_tbl_graph() %>% 
    mutate(degree = centrality_degree())-> g.affl
  
  gorder(g.affl) -> total.c.no
  getgcc(g.affl) -> giant_component
  gorder(giant_component) -> gc.no
  giant_component %>%
    as_tbl_graph() %>%
    as_tibble() %>%
    summarise(avg.degree = mean(degree)) %>%
    pull(avg.degree) -> avg.degree
  
  tibble(year = yr,total.c.no,gc.no,avg.degree)
    
}


all = tibble()
for(i in 1981:2018){
  bind_rows(all,get_metrics(i)) -> all
}

all %>%
  mutate(gc.prop = gc.no/total.c.no) %>%
  select(year,gc.prop,everything()) -> all_metrics

all_metrics %>%
  select(year,gc.prop,avg.degree) %>%
  gather(key = class,value = value, -year) %>%
  ggplot(aes(year,value,colour = class)) +
  geom_point(aes(shape = class)) + geom_smooth(aes(linetype = class)) + scale_y_log10() +
  theme_bw() + theme(legend.position=c(0,1), legend.justification=c(0,1))+
  theme(legend.background=element_rect(fill="white", colour="black")) +
  theme(legend.title=element_blank()) +
  ylab("Network connectedness") + xlab("Year") -> plot

p=1
ggsave("Fig_4.eps",plot,dpi = 400,width = 5*p,height = 5*p)

#### export supplementary table S1 and S2
eco_df %>% 
  select(ISSN,contains("journal")) %>% 
  distinct(ISSN,.keep_all = T) %>% 
  rename(JOURNAL = journal) %>% 
  write_csv("G:\\LTER\\BIOSCIENCE_RESUBMIT\\SUPPL\\S1_Table.csv")

lter_df %>% 
  transmute(YEAR = year,JOURNAL = journal,TITLE = Title,DOI = doi) %>% 
  write_csv("G:\\LTER\\BIOSCIENCE_RESUBMIT\\SUPPL\\S2_Table.csv")
  

  

