

library(pacman)
p_load(tidyverse,tidytext,gridExtra,ggrepel)
p_load(ggraph,igraph,tidygraph,widyr)

load("BIOSCIENCE_RESUBMIT\\DATA\\lter.rds")
load("BIOSCIENCE_RESUBMIT\\DATA\\baseline.rds")

set.seed(2019)

lter_df %>% 
  select(year,eid,search_txt,entry_number,ISSN) %>% 
  inner_join(lter_au) %>% 
  filter(order == 1) %>% 
  left_join(lter_aff) -> year_issn_country

# country contribution of LTER work
year_issn_country %>% 
  count(country) %>% 
  arrange(desc(n))

year_issn_country %>% 
  drop_na(country) %>%     # 3643
  count(year,ISSN,country) -> lter_str

eco_df %>% 
  select(year,eid,search_txt,entry_number,ISSN) %>% 
  inner_join(eco_au) %>% 
  filter(order == 1) %>% 
  left_join(eco_aff) %>% 
  drop_na(country) %>% 
  inner_join(lter_str %>% select(-n)) %>% 
  select(year,ISSN,country,eid,search_txt,entry_number) -> eco_eid_pool

get_table = function(eid_tbl){
  eid_tbl %>% 
    inner_join(eco_eid_pool) %>% 
    inner_join(eco_aff) %>% 
    select(year,eid,afid) %>% 
    rename(affl = afid,id = eid)-> dt_washed
    
  dt_washed %>%
    group_by(year) %>%
    pairwise_count(affl,id,upper = F) %>%
    ungroup() %>%
    filter(item1 > item2) -> bind.1
  
  dt_washed %>%
    group_by(year) %>%
    pairwise_count(affl,id,upper = F) %>%
    ungroup() %>%
    filter(item1 < item2) -> bind.2
  
  bind.1 %>%
    mutate(i1 = item2,i2 = item1) %>%
    transmute(year,item1 = i1,item2 = i2,n) %>%
    bind_rows(bind.2) %>%
    group_by(year) %>%
    distinct(item1,item2) %>%
    ungroup() %>%
    count(item1,item2) %>%
    filter(item1 != "") -> temporal_collaboration
  
  temporal_collaboration
}

get_metrics = function(dt){
  dt%>%
    summarise(m3 = sum(n>=3),m5 = sum(n>=5)) 
}


year_issn_country %>% 
  drop_na(country) %>% 
  select(eid) -> lter_eid

lter_eid %>% 
  get_table() %>% 
  get_metrics() -> lter_metrics

# permutation eco_eid_pool lter_str

system.time({
  all = tibble()
  for(i in 1:99){
    lter_str %>%
      inner_join(eco_eid_pool) %>% 
      group_by(ISSN,year,country,n) %>%
      nest() %>%
      mutate(samp = map2(data,n,sample_n)) %>%
      unnest(samp) %>% 
      select(eid)-> test_eid
    
    test_eid %>% get_table() %>% get_metrics() -> newline
    all = bind_rows(all,newline)
  }
})


all %>% mutate(class = "Baseline") -> all_bs

read_csv("BIOSCIENCE_RESUBMIT\\DATA\\mc_100.csv") -> mc_100

lter_metrics %>%
  mutate(class = c("LTER")) %>%
  bind_rows(all_bs) -> mc_100

mc_100 %>%  
  gather(key = "key",value = "value",-class) %>%
  filter(class == "LTER") -> lter_highlight

mc_100 %>%  
  gather(key = "key",value = "value",-class) %>%
  ggplot(aes(x = key, y = value,fill = key)) + 
  #geom_jitter(aes(shape = class,colour = key),size = 2.5) +
  geom_text_repel(data=lter_highlight, label="LTER",color = "red", 
                  fontface = "bold") +
  #geom_text(data=lter_highlight, label="LTER", vjust=1) +
  geom_boxplot() + scale_y_log10() +
  geom_point(data = lter_highlight,color = "red",shape = 17,size = 3) +
  scale_x_discrete(labels = c(">=3 years",">=5 years")) +
  ylab("No. of pairwise collaboration\n") + xlab("")+ 
  theme_bw() + 
  theme(legend.position = "none") +
  theme(axis.text.x = element_text(size = 11))

# mc_100 %>% 
#   write_csv("G:\\LTER\\BIOSCIENCE_RESUBMIT\\DATA\\mc_100.csv")

mc_100 %>% 
  group_by(class) %>% 
  summarise_all(list(mean))


## LTER detailed
lter_eid %>% 
  get_table() %>% 
  arrange(desc(n))-> lter_table

lter_aff %>% 
  mutate(affilname = str_c(affilname,city,country,sep = ", ")) %>% 
  select(afid,affilname) %>% 
  unique()-> afid_name

lter_table %>% 
  inner_join(afid_name,by = c("item1"="afid")) %>% 
  inner_join(afid_name,by = c("item2"="afid")) %>% 
  arrange(desc(n)) %>% 
  transmute(Institution1 = affilname.x,
            Institution2 = affilname.y,
            collaboration_years = n) %>% 
  write_csv("G:\\LTER\\BIOSCIENCE_RESUBMIT\\DATA\\long_term_inst_pairs.csv")

read_csv("G:\\LTER\\BIOSCIENCE_RESUBMIT\\DATA\\long_term_inst_pairs.csv") -> lt


## dig into details

# get site info
read_csv("G:\\LTER\\BIOSCIENCE_RESUBMIT\\DATA\\LTER-network-library-2019004-25.csv") -> lter_raw
lter_raw %>% 
  transmute(year = `Publication Year`,
            Title,
            site = `Manual Tags`) %>% 
  filter(between(year,1981,2018)) %>% 
  distinct(Title,.keep_all = T) %>% 
  unnest_tokens(site,site,str_split,pattern = "; ") %>% 
  filter(str_detect(site,"^lter-")) %>% 
  mutate(site = str_to_upper(site)) %>% 
  group_by(year,Title) %>% 
  summarise(site = str_c(site,collapse = "; ")) %>% 
  ungroup()-> site_info

lter_aff %>% 
  group_by(search_txt,entry_number) %>% 
  summarise(afid = str_c(afid,collapse = "; ")) -> afid_info

lter_df %>% 
  select(eid,year,Title,search_txt,entry_number) %>% 
  inner_join(site_info) %>% 
  inner_join(afid_info) %>% 
  select(year,eid,site,afid) -> site_afid

# afid pairs to sites
site_afid %>% 
  unnest_tokens(afid,afid,token = str_split,pattern = "; ") %>% 
  mutate(eid2 = eid) %>% 
  group_by(year,eid,site) %>% 
  pairwise_count(afid,eid2) %>% 
  ungroup() %>%
  mutate(item1 = as.integer(item1),item2 = as.integer(item2)) %>% 
  filter(item1 < item2) %>% 
  select(-n) -> eid_afid_pairs_sites

###### tables to join

lter_table %>% 
  inner_join(eid_afid_pairs_sites) %>% 
  group_by(item1,item2) %>% 
  distinct(eid) %>% 
  summarise(paper_no = n()) %>% 
  ungroup() -> afid_pair_paper_no

lter_table %>% 
  inner_join(eid_afid_pairs_sites) %>% 
  group_by(item1,item2) %>% 
  arrange(desc(n),year) %>% 
  distinct(year,.keep_all = T) %>% 
  summarise(year = str_c(year,collapse = ", "))  %>% 
  ungroup() -> afid_pair_year

lter_table %>% 
  inner_join(eid_afid_pairs_sites) %>% 
  inner_join(lter_df %>% select(eid,search_txt,entry_number)) %>% 
  inner_join(lter_au) %>% 
  group_by(item1,item2,authid,authname) %>% 
  distinct(year) %>% 
  summarise(auth_year = n()) %>% 
  ungroup()-> afid_pair_author_year
lter_table %>% 
  inner_join(eid_afid_pairs_sites) %>% 
  inner_join(lter_df %>% select(eid,search_txt,entry_number)) %>% 
  inner_join(lter_au) %>% 
  group_by(item1,item2) %>% 
  count(authid,authname) %>% 
  inner_join(afid_pair_author_year) %>% 
  mutate(authname_n = str_c(authname,"(",auth_year,"/",n,")")) %>% 
  #mutate(authname_n = str_c(authname,"(",auth_year,")")) %>% 
  arrange(desc(n)) %>% 
  summarise(author_n = str_c(authname_n,collapse = ", ")) %>% 
  ungroup()-> afid_pair_author_n
  
lter_table %>% 
  inner_join(eid_afid_pairs_sites) %>% 
  inner_join(lter_df %>% select(eid,keyword))  %>% 
  unnest_tokens(keyword,keyword,token = str_split,pattern = " \\| ") %>% 
  group_by(item1,item2) %>% 
  count(keyword) %>% 
  filter(keyword != "") %>% 
  mutate(keyword_n = str_c(keyword,"(",n,")")) %>% 
  arrange(desc(n)) %>% 
  summarise(keyword_n = str_c(keyword_n,collapse = ", ")) %>% 
  ungroup() -> afid_pair_keyword_n

lter_table %>% 
  inner_join(eid_afid_pairs_sites) %>% 
  unnest_tokens(site,site,token = str_split,pattern = "; ") %>% 
  mutate(site = str_to_upper(site) %>% str_replace("LTER-","")) %>% 
  group_by(item1,item2) %>% 
  count(site) %>% 
  mutate(site_n = str_c(site,"(",n,")")) %>% 
  arrange(desc(n)) %>% 
  summarise(site_n = str_c(site_n,collapse = ", ")) %>% 
  ungroup() -> afid_pair_site_n

lter_table %>% 
  inner_join(afid_name,by = c("item1"="afid")) %>% 
  inner_join(afid_name,by = c("item2"="afid")) %>% 
  arrange(desc(n)) %>% 
  rename(Institution1 = affilname.x,
            Institution2 = affilname.y,
            collaboration_years = n) -> afid_pair_afid_name

lter_aff %>% 
  distinct(afid,city) %>% 
  mutate(city = ifelse(city == "Washington, D.C.","Washington",city)) -> afid_city
lter_table %>% 
  inner_join(afid_city,by = c("item1"="afid")) %>% 
  inner_join(afid_city,by = c("item2"="afid")) %>% 
  arrange(desc(n)) %>% 
  rename(City1 = city.x,
         City2 = city.y) -> afid_pair_city

afid_pair_afid_name %>% 
  inner_join(afid_pair_paper_no) %>% 
  inner_join(afid_pair_year) %>% 
  inner_join(afid_pair_city) %>% 
  inner_join(afid_pair_author_n) %>% 
  inner_join(afid_pair_keyword_n) %>% 
  inner_join(afid_pair_site_n) -> afid_pair_all_raw



afid_pair_all_raw %>% 
  select(-item1,-item2) %>% 
  transmute(Institution1,Institution2, City1, City2,
            paper_no,total_collaboration_years = collaboration_years,
            year_in_detail = year,author_n,keyword_n,site_n) -> afid_pair_all


## site
afid_pair_all %>% 
  filter(total_collaboration_years >= 5) %>% 
  select(paper_no,site_n) %>% 
  mutate(first_site_n = str_extract(site_n,"([0-9]+)") %>% as.numeric()) %>% 
  mutate(prop = first_site_n/paper_no) %>% 
  #filter(prop == 1)
  summarise(avg = mean(prop)) 

## author
afid_pair_all %>% 
  filter(total_collaboration_years >= 3) %>% 
  select(paper_no,author_n) %>% 
  mutate(first_author_n = str_extract(author_n,"([0-9]+)") %>% as.numeric()) %>% 
  mutate(prop = first_author_n/paper_no) %>% 
  summarise(mean(prop))

lter_table %>% 
  inner_join(eid_afid_pairs_sites) %>% 
  inner_join(lter_df %>% select(eid,search_txt,entry_number)) %>% 
  inner_join(lter_au) %>% 
  group_by(item1,item2) %>% 
  count(authid,authname) %>% 
  inner_join(afid_pair_author_year) %>% 
  arrange(desc(auth_year)) %>% 
  filter(auth_year >= 10) %>% 
  ungroup() %>% 
  distinct(authid)  -> select_au_id

lter_au %>% 
  #inner_join(select_au_id) %>% 
  distinct(authid,afid) %>% 
  na.omit() %>% 
  count(authid) %>% 
  summarise(mean(n))

## city
(afid_pair_all %>% 
    filter(total_collaboration_years <5) %>%  
  filter(City1 == City2) %>% 
    nrow)/nrow(afid_pair_all)

(afid_pair_all %>% 
  filter(total_collaboration_years >= 5) %>% 
  filter(City1 == City2) %>% 
  nrow )/nrow(afid_pair_all %>% 
           filter(total_collaboration_years >= 5) )

## keywords


lter_table %>% 
  filter(n >= 5) %>% 
  inner_join(eid_afid_pairs_sites) %>% 
  inner_join(lter_df %>% select(eid,keyword))  %>% 
  unnest_tokens(keyword,keyword,token = str_split,pattern = " \\| ") %>% 
  filter(keyword != "") %>% 
  count(keyword) %>% 
  arrange(desc(n))

p_load(rio)

# export(afid_pair_all,"G:\\LTER\\BIOSCIENCE_RESUBMIT\\DATA\\long_term_collaboration.xlsx")








