
library(pacman)
p_load(tidyverse,tidytext,gridExtra,data.table)
p_load(ggraph,igraph,tidygraph,widyr)
p_load(geosphere)

load("BIOSCIENCE_RESUBMIT\\DATA\\lter.rds")
load("BIOSCIENCE_RESUBMIT\\DATA\\baseline.rds")

fread("cities500.txt",encoding = "UTF-8") %>%
  as_tibble() %>%
  transmute(name = V2,latitude = V5,longtitude = V6) %>%
  distinct(name,.keep_all = T) %>%
  mutate(city = str_to_lower(name)) %>% 
  select(-name)-> city

lter_df %>% 
  select(year,eid,search_txt,entry_number,ISSN) %>% 
  inner_join(lter_au) %>% 
  filter(order == 1) %>% 
  left_join(lter_aff) -> year_issn_country

# country contribution of LTER work
year_issn_country %>% 
  count(country) %>% 
  arrange(desc(n))

year_issn_country %>% 
  drop_na(country) %>%     # 3643
  count(year,ISSN,country) -> lter_str

eco_df %>% 
  select(year,eid,search_txt,entry_number,ISSN) %>% 
  inner_join(eco_au) %>% 
  filter(order == 1) %>% 
  left_join(eco_aff) %>% 
  drop_na(country) %>% 
  inner_join(lter_str %>% select(-n)) %>% 
  select(year,ISSN,country,eid,search_txt,entry_number) -> eco_eid_pool
##################################################################################
get_max_dist = function(dt){
  dt %>% 
    as.matrix() %>% 
    distm %>% 
    max()
}

system.time({eco_df %>% 
              select(eid,search_txt,entry_number) %>% 
              inner_join(eco_aff) %>% 
              mutate(city = str_to_lower(city)) %>% 
              inner_join(city) %>% 
              distinct(eid,longtitude,latitude) %>% 
              group_by(eid) %>% 
              nest(data = c(longtitude,latitude)) %>%
              mutate(max_dist = map(data,get_max_dist)) %>%
              unnest(max_dist) -> eco_max_dist})

# user  system elapsed 
# 8227.39  536.08 9815.85 

eco_max_dist %>% 
  select(-data) %>% 
  ungroup -> eid_max_dist

# write_rds(eid_max_dist,"BIOSCIENCE_RESUBMIT\\DATA\\eid_max_dist.rds")
##################################################################################
read_rds("BIOSCIENCE_RESUBMIT\\DATA\\eid_max_dist.rds") -> eco_max_dist

lter_df %>% 
  select(year,eid) %>% 
  inner_join(eco_max_dist) %>% 
  mutate(period = sjmisc::rec(year, 
                              rec = "min:1990=1981-1990;
                              1991:2000=1991-2000;
                              2001:2010=2001-2010;
                              2011:max=2011-2018")) %>% 
  group_by(period) %>% 
  summarise(dist = mean(max_dist)) %>% 
  mutate(group = "LTER")-> lter_dist

# permutation eco_eid_pool lter_str

system.time({
  all = tibble()
  for(i in 1:99){
    lter_str %>%
      inner_join(eco_eid_pool) %>% 
      group_by(ISSN,year,country,n) %>%
      nest() %>%
      mutate(samp = map2(data,n,sample_n)) %>%
      unnest(samp) %>% 
      ungroup %>% 
      select(year,eid)-> test_eid
    
    test_eid %>% 
      inner_join(eco_max_dist) %>% 
      mutate(period = sjmisc::rec(year, 
                                  rec = "min:1990=1981-1990;
                              1991:2000=1991-2000;
                              2001:2010=2001-2010;
                              2011:max=2011-2018")) %>% 
      group_by(period) %>% 
      summarise(dist = mean(max_dist)) %>% 
      mutate(group = "Baseline") -> newline
    
    all = bind_rows(all,newline)
  }
})

# user  system elapsed 
# 166.26   16.14  237.06 

all -> baseline

lter_dist %>% 
  bind_rows(baseline) -> for_plot

# write_rds(for_plot,"BIOSCIENCE_RESUBMIT\\DATA\\for_plot.rds")

read_rds("BIOSCIENCE_RESUBMIT\\DATA\\for_plot.rds") -> for_plot

for_plot %>% 
  ggplot(aes(x = period,y = dist)) +
  geom_point(mapping = aes(x = period,y = dist),
             data = lter_dist,colour = "red",shape = 1,size = 5) +
  geom_boxplot()+ ylab("Average max distance between collaborating institutes (Mm)\n") +
  geom_line(mapping = aes(x = period,y = dist,group = 1),
            data = lter_dist,colour = "red",size = 1) +
  xlab("") +
  stat_summary(fun.y=mean, geom="point", shape=20, size=5,  color="blue", fill="blue") +
  stat_summary(fun.y=mean, geom="line", aes(group=1),color="blue",linetype = "dashed",size = 1) +
  theme_bw()+
  annotate("text",x = 2,y = 5e6,label = "LTER",colour = "red",size = 5) +
  annotate("text",x = 3,y = 3e6,label = "Baseline",colour = "blue",size = 5)+
  scale_y_continuous(breaks = c(0,2e6,4e6,6e6,8e6),
                     labels = c(0,2,4,6,8))


lter_df %>% 
  inner_join(eco_max_dist) %>% 
  arrange(desc(max_dist)) %>% 
  select(Title,year,max_dist,journal) %>% 
  slice(1:20) -> a

"bioscience\\new_codes\\data_refresh\\S4_Table.csv" %>% 
  read_csv %>% 
  transmute(Title = title) %>% 
  slice(1:15) -> b 

b %>% 
  anti_join(a)

a %>% 
  anti_join(b)


