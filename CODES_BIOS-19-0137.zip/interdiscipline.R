

library(pacman)
p_load(tidyverse,rio,hrbrthemes)

library(extrafont)
# font_import()
loadfonts(device = "win")

import("BIOSCIENCE_RESUBMIT\\DATA\\CiteScore_Metrics_2011-2018_download.xlsx",
       sheet = "2018 All",skip = 1) %>% as_tibble -> journal_table

import("BIOSCIENCE_RESUBMIT\\DATA\\LTER-network-library-2019004-25.csv") %>% 
  as_tibble() %>% 
  filter(`Item Type` == "journalArticle") %>% 
  select(Key,journal = `Publication Title`,year = `Publication Year`) %>% 
  distinct(Key,.keep_all = T)-> lter_journal_pub

journal_table %>% 
  select(journal = Title,issn = `Print ISSN`,
         subject = `Scopus Sub-Subject Area`) %>% 
  right_join(lter_journal_pub) %>% 
  na.omit %>% 
  count(subject) %>% 
  top_n(25) %>% 
  select(subject) -> sel_subject


journal_table %>% 
  select(journal = Title,issn = `Print ISSN`,
         subject = `Scopus Sub-Subject Area`) %>% 
  right_join(lter_journal_pub) %>% 
  na.omit() %>% 
  mutate(period = sjmisc::rec(year, 
                              rec = "min:1990=1981-1990;
                              1991:2000=1991-2000;
                              2001:2010=2001-2010;
                              2011:max=2011-2018")) %>% 
  group_by(period) %>% 
  count(subject) %>% 
  #mutate(prop = n/sum(n)) %>% 
  ungroup() %>% 
  inner_join(sel_subject) -> subj_paper_no

journal_table %>% 
  select(journal = Title,issn = `Print ISSN`,
         subject = `Scopus Sub-Subject Area`) %>% 
  right_join(lter_journal_pub) %>% 
  na.omit() %>% 
  mutate(period = sjmisc::rec(year, 
                              rec = "min:1990=1981-1990;
                              1991:2000=1991-2000;
                              2001:2010=2001-2010;
                              2011:max=2011-2018")) %>% 
  distinct(Key,period) %>% 
  count(period) %>% 
  rename(total = n)-> period_paper_no

subj_paper_no %>% 
  inner_join(period_paper_no) %>% 
  mutate(prop = n/total) %>% 
  ggplot(aes(x = period,y = subject,fill = prop*100)) +
  geom_tile() +
  scale_fill_distiller(palette = "Spectral") +
  labs(x = "\nPeriod",y = "Subdisciplines\n",fill = "Proportion (%)") +
  theme_ipsum(base_size = 15,
              base_family = "Times New Roman",
              axis_title_face = "bold",
              axis_title_size = 20,
              axis_title_family = "Times New Roman",
              axis_title_just = "m")


subj_paper_no %>% 
  inner_join(period_paper_no) %>% 
  mutate(prop = n/total) %>% 
  group_by(subject) %>% 
  summarise(dif = last(prop) - first(prop)) %>% 
  inner_join(sel_subject) %>% 
  top_n(10) %>% 
  arrange(desc(dif))


#################################################################
journal_table %>% 
  select(journal = Title,issn = `Print ISSN`,
         subject = `Scopus Sub-Subject Area`) %>% 
  right_join(lter_journal_pub) %>% 
  na.omit() %>% 
  mutate(period = sjmisc::rec(year, 
                              rec = "min:1990=1981-1990;
                              1991:2000=1991-2000;
                              2001:2010=2001-2010;
                              2011:max=2011-2018")) %>% 
  group_by(period) %>% 
  count(subject) %>% 
  #mutate(prop = n/sum(n)) %>% 
  ungroup() %>% 
  inner_join(sel_subject) %>% 
  ggplot(aes(x = period,y = subject,fill = n)) +
  geom_tile() +
  scale_fill_distiller(palette = "Spectral") +
  labs(x = "\nPeriod",y = "Subdisciplines\n",fill = "No. of papers") +
  theme_light() -> plot
plot
p=1
ggsave("Fig_5.eps",plot,dpi = 400,width = 6,height = 4,limitsize = F)  





